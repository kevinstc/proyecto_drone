# matlab_quadcopter
Quadcopter Model for Matlab & Octave Simulation
based on this equation :
![alt text](https://raw.githubusercontent.com/2black0/matlab_quadcopter/master/quad_equation.jpg)
![alt text](https://raw.githubusercontent.com/2black0/matlab_quadcopter/master/control_input.jpg)


source : https://www.kth.se/polopoly_fs/1.588039.1550155544!/Thesis%20KTH%20-%20Francesco%20Sabatino.pdf

Just download all file, and run :
>quadrun

in the last itteration the position (linear and angular) will be shown and saved
![alt text](https://raw.githubusercontent.com/2black0/matlab_quadcopter/master/figure1.jpg)
![alt text](https://raw.githubusercontent.com/2black0/matlab_quadcopter/master/figure2.jpg)
